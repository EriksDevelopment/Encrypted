﻿using System;
using System.Threading;

namespace Encrypted
{
    class Program
    {
        static bool running = true;
        static void Main()
        {
            while (running)
            {
                Console.Clear();
                Console.WriteLine("=== ENCRYPTED ===");
                Console.WriteLine("[1] Encrypt");
                Console.WriteLine("[2] Decrypt");
                Console.WriteLine("[4] Quit");
                Console.Write("Choose an option: ");
                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        Console.Clear();
                        Console.Write("Enter text to encrypt: ");
                        string textToEncrypt = Console.ReadLine();
                        if (string.IsNullOrWhiteSpace(textToEncrypt))
                        {
                            Console.WriteLine("Text cannot be empty.");
                            break;
                        }
                        Console.Write("Enter shift value: ");
                        if (!int.TryParse(Console.ReadLine(), out int encryptShift))
                        {
                            Console.WriteLine("Invalid shift value. Must be a number.");
                            break;
                        }
                        string encrypted = Cipher.EncryptCaesar(textToEncrypt, encryptShift);
                        Console.WriteLine($"Original Text: {textToEncrypt}");
                        Console.WriteLine($"Encrypted: {encrypted}");
                        break;
                    case "2":
                        Console.Clear();
                        Console.Write("Enter text to decrypt: ");
                        string textToDecrypt = Console.ReadLine();
                        if (string.IsNullOrWhiteSpace(textToDecrypt))
                        {
                            Console.WriteLine("Text cannot be empty.");
                            break;
                        }
                        Console.Write("Enter shift value: ");
                        if (!int.TryParse(Console.ReadLine(), out int decryptShift))
                        {
                            Console.WriteLine("Invalid shift value. Must be a number.");
                            break;
                        }
                        string decrypted = Cipher.DecryptCaesar(textToDecrypt, decryptShift);
                        Console.WriteLine($"Original Text: {textToDecrypt}");
                        Console.WriteLine($"Decrypted: {decrypted}");
                        break;
                    case "4":
                        Quit();
                        continue;
                    default:
                        Console.WriteLine("Invalid option. Try again.");
                        break;
                }
                Console.WriteLine("\nPress Enter to continue...");
                Console.ReadLine();
            }
        }
        static void Quit()
        {
            Console.WriteLine("Quitting...");
            Thread.Sleep(1000);
            running = false;
        }
    }
}