using System;

namespace Encrypted
{
    public static class Cipher
    {
        public static string EncryptCaesar(string input, int shift)
        {
            char[] buffer = input.ToCharArray();
            for (int i = 0; i < buffer.Length; i++)
            {
                char letter = buffer[i];
                if (char.IsLetter(letter))
                {
                    char d = char.IsUpper(letter) ? 'A' : 'a';
                    letter = (char)((((letter + shift) - d) % 26 + 26) % 26 + d); // säkerställer positivt resultat
                    buffer[i] = letter;
                }
            }
            return new string(buffer);
        }
        public static string DecryptCaesar(string input, int shift)
        {
            return EncryptCaesar(input, 26 - shift);
        }
    }
}